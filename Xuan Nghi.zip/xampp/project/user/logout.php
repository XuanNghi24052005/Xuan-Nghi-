<?php
// Include functions.php để sử dụng hàm logout
require_once '../includes/functions.php'; // Thêm '../' để di chuyển lên một cấp thư mục

// Gọi hàm logout để hủy session và chuyển hướng về trang đăng nhập
logout();

