<?php
require_once '../config.php';

// Kiểm tra nếu form đã được submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $title = $_POST['title'];
    $content = $_POST['content'];
    $module_id = $_POST['module_id']; // Lấy module_id từ form
    $image = null; // Mặc định không có ảnh

    // Kiểm tra xem có ảnh được tải lên không
    if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
        $image_name = $_FILES['image']['name'];
        $image_tmp = $_FILES['image']['tmp_name'];

        // Xử lý tên ảnh để tránh xung đột
        $image_name = time() . '_' . $image_name;
        $image_path = 'uploads/' . $image_name;

        // Kiểm tra thư mục uploads có tồn tại chưa, nếu không tạo mới
        if (!file_exists('uploads')) {
            mkdir('uploads', 0777, true);
        }

        // Di chuyển ảnh từ thư mục tạm vào thư mục uploads
        if (move_uploaded_file($image_tmp, $image_path)) {
            $image = $image_path;
        } else {
            echo "Error uploading image.";
            exit;
        }
    }

    // Cập nhật bài viết vào cơ sở dữ liệu
    if ($image) {
        // Nếu có ảnh mới, cập nhật ảnh
        $stmt = $pdo->prepare("UPDATE posts SET title = ?, content = ?, module_id = ?, image = ? WHERE id = ?");
        $stmt->execute([$title, $content, $module_id, $image, $id]);
    } else {
        // Nếu không có ảnh mới, chỉ cập nhật title, content, module_id
        $stmt = $pdo->prepare("UPDATE posts SET title = ?, content = ?, module_id = ? WHERE id = ?");
        $stmt->execute([$title, $content, $module_id, $id]);
    }

    // Sau khi cập nhật thành công, chuyển hướng về trang quản lý bài viết
    header('Location: manage_posts.php');
    exit;
}
