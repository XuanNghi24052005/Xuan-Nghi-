<?php
session_start();
require_once '../config.php';
include '../includes/header.php'; // Header dùng chung  
// Kiểm tra nếu người dùng chưa đăng nhập
if (!isset($_SESSION['user'])) {
    header('Location: login.php'); // Chuyển hướng về trang đăng nhập nếu chưa đăng nhập
    exit();
}

$user_id = $_SESSION['user']['id']; // Lấy ID người dùng từ session

// Lấy thông tin người dùng từ cơ sở dữ liệu
$query = $pdo->prepare("SELECT username, email FROM users WHERE id = ?");
$query->execute([$user_id]);
$user = $query->fetch(PDO::FETCH_ASSOC);

// Cập nhật thông tin nếu người dùng gửi form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Lấy dữ liệu từ form và làm sạch dữ liệu
    $username = sanitize_input($_POST['username']);
    $email = sanitize_input($_POST['email']);
    $password = $_POST['password'] ? sanitize_input($_POST['password']) : null; // Nếu có mật khẩu mới

    // Gọi hàm update_profile để cập nhật thông tin
    update_profile($user_id, $username, $email, $password);

    // Cập nhật lại thông tin trong session
    $_SESSION['user']['username'] = $username;
    $_SESSION['user']['email'] = $email;

    // Hiển thị thông báo thành công
    $message = "Profile updated successfully!";
}

// Hàm cập nhật thông tin người dùng
function update_profile($user_id, $new_username, $new_email, $new_password = null) {
    global $pdo;

    try {
        if ($new_password) {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, password = ? WHERE id = ?");
            $stmt->execute([$new_username, $new_email, $hashed_password, $user_id]);
        } else {
            $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ? WHERE id = ?");
            $stmt->execute([$new_username, $new_email, $user_id]);
        }
    } catch (PDOException $e) {
        die("Error updating profile: " . $e->getMessage());
    }
}

// Hàm làm sạch dữ liệu đầu vào để tránh XSS và SQL Injection
function sanitize_input($data) {
    $data = trim($data); // Loại bỏ khoảng trắng thừa
    $data = stripslashes($data); // Loại bỏ ký tự backslashes
    $data = htmlspecialchars($data); // Chuyển đổi các ký tự đặc biệt thành HTML entities
    return $data;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .form-container {
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
            background: #ffffff;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        .modal {
            display: none;
            justify-content: center;
            align-items: center;
            background-color: rgba(0, 0, 0, 0.5);
        }
    </style>
</head>
<body>

<div class="container">
    <h1 class="text-center text-primary my-4">Edit Profile</h1>

    <?php if (isset($message)): ?>
        <div class="alert alert-success text-center" role="alert">
            <?= $message ?>
        </div>
    <?php endif; ?>

    <div class="form-container">
        <form action="<?= $_SERVER['PHP_SELF']; ?>" method="POST">
            <div class="mb-3">
                <label for="username" class="form-label">Username</label>
                <input type="text" class="form-control" name="username" value="<?= htmlspecialchars($user['username']); ?>" required>
            </div>

            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" name="email" value="<?= htmlspecialchars($user['email']); ?>" required>
            </div>

            <div class="mb-3">
                <label for="password" class="form-label">New Password (optional)</label>
                <input type="password" class="form-control" name="password" placeholder="Enter new password (leave blank if not changing)">
            </div>

            <div class="text-center">
                <button type="submit" class="btn btn-primary">Update Profile</button>
            </div>
        </form>
    </div>

    <div class="text-center mt-4">
        <a href="index.php" class="btn btn-link">Back to Home</a>
    </div>
</div>

<!-- Modal for success message -->
<div id="updateModal" class="modal">
    <div class="modal-content text-center p-4 bg-white">
        <h2 class="text-success">Profile updated successfully!</h2>
        <button class="btn btn-primary mt-3" onclick="window.location.href='/project/user/profile.php';">Go to Profile</button>
    </div>
</div>

<!-- Bootstrap Bundle JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Show modal if update is successful
    <?php if (isset($message)): ?>
        const modal = document.getElementById('updateModal');
        modal.style.display = 'flex';
        setTimeout(() => modal.style.display = 'none', 3000);
    <?php endif; ?>
</script>

</body>
</html>

<?php include '../includes/footer.php'; ?>