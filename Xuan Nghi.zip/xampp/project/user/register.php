<?php
require_once '../config.php';

// Start session and output buffering to ensure headers can be sent
ob_start();  // Start output buffering

include '../includes/header.php'; // Include header  

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get data from the form
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $role = 'user'; // Default is 'user', can be changed later

    // Hash password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Insert the user into the database
    $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)");
    $stmt->execute([$username, $email, $hashed_password, $role]);

    // Redirect to login page after successful registration
    header('Location: /project/user/login.php');
    exit(); // Make sure no further code is executed after header
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f9; }
        .form-container { max-width: 400px; margin: auto; padding: 30px; background-color: white; border-radius: 8px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); }
        h1 { text-align: center; margin-bottom: 30px; color: #333; }
        .modal { display: none; position: fixed; z-index: 1; left: 0; top: 0; width: 100%; height: 100%; background-color: rgba(0, 0, 0, 0.4); }
        .modal-content { background-color: white; padding: 30px; border-radius: 8px; width: 350px; margin: 150px auto; text-align: center; box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2); }
        .modal h2 { margin-bottom: 20px; font-size: 20px; color: #28a745; }
        .close { color: #aaa; font-size: 28px; font-weight: bold; position: absolute; top: 10px; right: 20px; }
        .close:hover, .close:focus { color: black; text-decoration: none; cursor: pointer; }
        .btn-back { background-color: #28a745; color: white; padding: 12px 20px; border-radius: 6px; font-size: 16px; text-decoration: none; display: inline-block; margin-top: 15px; cursor: pointer; transition: background-color 0.3s; }
        .btn-back:hover { background-color: #218838; }
    </style>
</head>
<body>

<!-- Registration Form -->
<h1>Register Account</h1>
<div class="form-container">
    <form action="" method="POST" novalidate>
        <div class="mb-3">
            <label for="username" class="form-label">Username</label>
            <input type="text" class="form-control" name="username" id="username" required>
            <div class="invalid-feedback">Please enter a username.</div>
        </div>

        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" name="email" id="email" required>
            <div class="invalid-feedback">Please enter a valid email address.</div>
        </div>

        <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" class="form-control" name="password" id="password" required>
            <div class="invalid-feedback">Please enter a password.</div>
        </div>

        <button type="submit" class="btn btn-primary w-100">Register</button>
    </form>
</div>

<!-- Back to Home Button -->
<div class="text-center mt-3">
    <a href="index.php" class="btn-back">Back to Home</a>
</div>

<!-- Success Modal -->
<?php if (isset($_GET['success']) && $_GET['success'] == 'true'): ?>
    <div id="successModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <h2>Registration Successful!</h2>
            <p>You have successfully registered. Click below to go back to the homepage.</p>
            <a href="index.php" class="btn-back">Back to Home</a>
        </div>
    </div>
    <script>
        // Show the modal
        document.getElementById("successModal").style.display = "block";
        
        // Close the modal
        function closeModal() {
            document.getElementById("successModal").style.display = "none";
        }
    </script>
<?php endif; ?>

<!-- Bootstrap 5 JS and dependencies -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>

<script>
    // Bootstrap 5 form validation
    (function () {
        'use strict'
        var forms = document.querySelectorAll('.needs-validation')
        Array.prototype.slice.call(forms)
            .forEach(function (form) {
                form.addEventListener('submit', function (event) {
                    if (!form.checkValidity()) {
                        event.preventDefault()
                        event.stopPropagation()
                    }
                    form.classList.add('was-validated')
                }, false)
            })
    })()
</script>

</body>
</html>

<?php
// Include footer only after output buffering is used
include '../includes/footer.php';

// End output buffering
ob_end_flush();
?>
