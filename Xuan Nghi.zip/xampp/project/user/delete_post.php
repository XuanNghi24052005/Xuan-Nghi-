<?php
require_once '../config.php'; // Kết nối cơ sở dữ liệu

if (isset($_GET['id'])) {
    $post_id = $_GET['id'];

    // Xóa tất cả các bình luận liên quan đến bài viết
    $stmt = $pdo->prepare("DELETE FROM comments WHERE post_id = ?");
    $stmt->execute([$post_id]);

    // Xóa bài viết
    $stmt = $pdo->prepare("DELETE FROM posts WHERE id = ?");
    $stmt->execute([$post_id]);

    echo 'Post deleted successfully!';
    header('Location: manage_posts.php'); // Quay lại trang quản lý bài viết
    exit;
}

