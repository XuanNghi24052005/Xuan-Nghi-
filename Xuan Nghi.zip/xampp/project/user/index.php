<?php
ob_start();
require_once '../config.php'; // Kết nối cơ sở dữ liệu
require_once '../includes/functions.php'; // Bao gồm các hàm xử lý

// Kiểm tra người dùng đã đăng nhập chưa
$is_logged_in = isset($_SESSION['user']); // Kiểm tra người dùng đã đăng nhập hay chưa

include '../includes/header.php'; // Header dùng chung  

// Lọc theo Module
$module_filter = isset($_GET['module_id']) ? (int)$_GET['module_id'] : 0;

// Truy vấn lấy danh sách các module
$modules_query = $pdo->query("SELECT * FROM modules");
$modules = $modules_query->fetchAll(PDO::FETCH_ASSOC);

// Lấy danh sách bài viết từ cơ sở dữ liệu, có lọc theo module nếu cần
$query = "SELECT posts.id, posts.title, posts.content, posts.image, posts.created_at, users.username, modules.name AS module_name
          FROM posts 
          JOIN users ON posts.user_id = users.id
          JOIN modules ON posts.module_id = modules.id";

if ($module_filter > 0) {
    $query .= " WHERE posts.module_id = :module_id";  // Thêm điều kiện lọc theo module
}

$stmt = $pdo->prepare($query);
if ($module_filter > 0) {
    $stmt->bindParam(':module_id', $module_filter, PDO::PARAM_INT);
}

$stmt->execute();
$posts = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>List of Questions</title>
    <style>
        /* Thiết kế popup nhỏ gọn */
        .popup {
            display: none;
            position: fixed;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            background-color: #28a745;
            color: white;
            padding: 10px 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            z-index: 1000;
            font-size: 16px;
            text-align: center;
        }

        .popup button {
            background-color: #dc3545;
            border: none;
            color: white;
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
        }

        .popup button:hover {
            background-color: #c82333;
        }

        /* Tổng thể thiết kế */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
            color: #333;
            margin: 0;
            padding: 0;
        }

        h1 {
            text-align: center;
            margin: 20px 0;
            font-size: 36px;
            color: #333;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .filter-form {
            margin-bottom: 20px;
            text-align: center;
        }

        .filter-form select,
        .filter-form button {
            padding: 12px 18px;
            font-size: 16px;
            border-radius: 8px;
            border: 1px solid #ddd;
            margin-right: 10px;
            cursor: pointer;
            transition: 0.3s ease;
        }

        .filter-form select {
            background-color: #fff;
        }

        .filter-form button {
            background-color: #007BFF;
            color: white;
            border: none;
        }

        .filter-form button:hover {
            background-color: #0056b3;
        }

        .card {
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            margin-bottom: 30px;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            word-wrap: break-word;
        }

        .card h3 {
            margin: 0;
            color: #333;
            font-size: 24px;
            line-height: 1.4;
        }

        .card p {
            margin: 8px 0;
            color: #555;
            line-height: 1.5;
        }

        .card img {
            width: 100%;
            height: auto;
            border-radius: 8px;
            margin-top: 15px;
            max-width: 600px; /* Giới hạn kích thước ảnh để không bị rộng quá */
            display: block; /* Chuyển ảnh thành block-level element */
            margin-left: auto; /* Căn giữa ảnh */
            margin-right: auto; /* Căn giữa ảnh */
        }

        .comments-section {
            margin-top: 25px;
            padding-top: 15px;
            border-top: 1px solid #ddd;
        }

        .comments-section h4 {
            font-size: 20px;
            color: #333;
            margin-bottom: 10px;
        }

        .comments-section ul {
            list-style: none;
            padding: 0;
        }

        .comments-section ul li {
            margin-bottom: 12px;
            color: #555;
        }

        .no-posts {
            text-align: center;
            color: #888;
            font-size: 18px;
        }

        .manage-posts-link {
            margin-top: 20px;
            margin-bottom: 20px;
        }

        .manage-posts-link a {
            font-size: 18px;
            font-weight: bold;
            color: #007BFF;
            text-decoration: none;
            border: 2px solid #007BFF;
            padding: 12px 24px;
            border-radius: 8px;
            background-color: #fff;
            transition: background-color 0.3s, color 0.3s;
        }

        .manage-posts-link a:hover {
            background-color: #007BFF;
            color: #fff;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>List of Questions</h1>
        <?php if ($is_logged_in): ?>
        <div class="manage-posts-link">
            <a href="/project/user/manage_posts.php">Manage Your Posts</a>
        </div>
        <?php endif; ?>

        <!-- Form lọc module và tìm kiếm -->
        <form method="GET" class="filter-form">
            <select name="module_id">
                <option value="0">All Modules</option>
                <?php foreach ($modules as $module): ?>
                    <option value="<?= $module['id'] ?>" <?= $module_filter == $module['id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($module['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <button type="submit">Apply</button>
        </form>
        
        <!-- Hiển thị popup nếu có thông báo -->
        <?php if (isset($_SESSION['message'])): ?>
            <div class="popup" id="popup">
                <p><?= htmlspecialchars($_SESSION['message']) ?></p>
            </div>
            <script>
                // Hiển thị popup và tự động ẩn sau 2s
                document.getElementById('popup').style.display = 'block';
                setTimeout(function() {
                    document.getElementById('popup').style.display = 'none';
                }, 2000);
            </script>
            <?php unset($_SESSION['message']); ?>
        <?php endif; ?>

        <!-- Các phần khác của trang -->
        <?php if (!empty($posts)): ?>
            <?php foreach ($posts as $post): ?>
                <div class="card" id="post-<?= $post['id'] ?>">
                    <h3><?= htmlspecialchars($post['title']) ?></h3>
                    <p><strong>Posted by:</strong> <?= htmlspecialchars($post['username']) ?></p>
                    <p><strong>Module:</strong> <?= htmlspecialchars($post['module_name']) ?></p>
                    <p><strong>Posted on:</strong> <?= $post['created_at'] ?></p>
                    <p><?= htmlspecialchars(substr($post['content'], 0, 100)) ?>...</p>
                    <?php if ($post['image']): ?>
                        <img src="<?= htmlspecialchars($post['image']) ?>" alt="Post Image">
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p class="no-posts">No posts available.</p>
        <?php endif; ?>
    </div>
</body>
</html>
