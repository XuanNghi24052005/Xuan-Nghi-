<?php
require_once '../config.php'; // Kết nối cơ sở dữ liệu

session_start(); // Bắt đầu session
include '../includes/header.php'; // Header dùng chung

// Kiểm tra nếu người dùng đã đăng nhập
if (!isset($_SESSION['user'])) {
    header('Location: login.php'); // Nếu chưa đăng nhập, chuyển hướng về trang login
    exit;
}

// Lấy ID người dùng từ session
$user_id = $_SESSION['user']['id'];

// Kiểm tra nếu form đã được submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $content = $_POST['content'];
    $module_id = $_POST['module_id']; // Lấy module_id từ form
    $image = null; // Nếu không có ảnh, set mặc định là null

    // Kiểm tra xem có ảnh được tải lên không
    if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
        // Lưu ảnh vào thư mục upload
        $image_name = $_FILES['image']['name'];
        $image_tmp = $_FILES['image']['tmp_name'];

        // Xử lý tên ảnh để tránh xung đột (Thêm thời gian vào tên ảnh)
        $image_name = time() . '_' . $image_name; // Thêm dấu thời gian vào tên ảnh

        $image_path = 'uploads/' . $image_name; // Đường dẫn ảnh

        // Kiểm tra thư mục uploads có tồn tại chưa, nếu không tạo mới
        if (!file_exists('uploads')) {
            mkdir('uploads', 0777, true);
        }

        // Di chuyển ảnh từ thư mục tạm đến thư mục uploads
        if (move_uploaded_file($image_tmp, $image_path)) {
            $image = $image_path; // Lưu đường dẫn ảnh vào biến $image
        } else {
            echo "Error uploading the image.";
            exit;
        }
    }

    // Thêm bài viết vào cơ sở dữ liệu
    $stmt = $pdo->prepare("INSERT INTO posts (title, content, user_id, module_id, image) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$title, $content, $user_id, $module_id, $image]);

    $success = true; // Đặt biến success thành true để hiển thị thông báo
}

// Lấy danh sách các module để hiển thị trong select
$query = $pdo->query("SELECT * FROM modules");
$modules = $query->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Post a Question</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .custom-container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        .popup {
            position: fixed;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            background-color: #28a745;
            color: white;
            padding: 10px 20px;
            border-radius: 8px;
            display: none;
            z-index: 1000;
            font-size: 18px;
            text-align: center;
        }
    </style>
</head>
<body class="bg-light">

    <?php if (isset($success) && $success): ?>
        <div class="popup" id="popupMessage">Your post has been successfully posted!</div>
    <?php endif; ?>

    <div class="container custom-container">
        <h1 class="text-center text-primary mb-4">Post a Question</h1>
        <form action="" method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="title" class="form-label">Title</label>
                <input type="text" class="form-control" name="title" id="title" placeholder="Enter your title" required>
            </div>

            <div class="mb-3">
                <label for="content" class="form-label">Content</label>
                <textarea class="form-control" name="content" id="content" rows="5" placeholder="Write your question here..." required></textarea>
            </div>

            <div class="mb-3">
                <label for="module_id" class="form-label">Select Module</label>
                <select class="form-select" name="module_id" id="module_id" required>
                    <option value="" selected disabled>Choose a module</option>
                    <?php foreach ($modules as $module): ?>
                        <option value="<?= $module['id'] ?>"><?= htmlspecialchars($module['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="mb-3">
                <label for="image" class="form-label">Upload Image (optional)</label>
                <input class="form-control" type="file" name="image" id="image">
            </div>

            <div class="d-grid">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </form>

        <div class="text-center mt-4">
            <a href="index.php" class="btn btn-link">Back to List</a>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
    <script>
        // Hiển thị popup và tự động ẩn sau 2 giây
        <?php if (isset($success) && $success): ?>
            document.getElementById('popupMessage').style.display = 'block';
            setTimeout(function() {
                document.getElementById('popupMessage').style.display = 'none';
            }, 2000);
        <?php endif; ?>
    </script>
</body>
</html>

<?php include '../includes/footer.php'; ?>
