<?php
require_once '../config.php'; // Kết nối cơ sở dữ liệu

session_start(); // Bắt đầu session
include '../includes/header.php'; // Header dùng chung  

// Kiểm tra nếu người dùng đã đăng nhập
if (!isset($_SESSION['user'])) {
    header('Location: login.php'); // Nếu chưa đăng nhập, chuyển hướng về trang login
    exit;
}

// Lấy ID người dùng từ session
$user_id = $_SESSION['user']['id'];

// Lấy danh sách bài viết của người dùng
$query = $pdo->prepare("SELECT posts.*, modules.name AS module_name FROM posts 
                        JOIN modules ON posts.module_id = modules.id 
                        WHERE posts.user_id = ?");
$query->execute([$user_id]);
$posts = $query->fetchAll(PDO::FETCH_ASSOC);

// Lấy danh sách ảnh để điền vào form sửa bài viết
$image_query = $pdo->query("SELECT DISTINCT image FROM posts WHERE image IS NOT NULL");
$images = $image_query->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Your Posts</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background-color: #f4f4f9; }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #007BFF;
            color: white;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        a {
            color: #007BFF;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
        .emoji {
            font-size: 20px;
            cursor: pointer;
        }
        img {
            max-width: 100px;
            height: auto;
        }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
        }
        .modal-content {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            width: 500px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .modal-header h2 {
            margin: 0;
        }
        .close {
            cursor: pointer;
            font-size: 24px;
            font-weight: bold;
            color: red;
        }
        .modal-body {
            margin-top: 15px;
        }
        input, textarea, select {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border-radius: 8px;
            border: 1px solid #ccc;
        }
        button {
            background-color: #007BFF;
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 8px;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
    </style>
    <script>
        function openModal(postId) {
            document.getElementById("modal" + postId).style.display = "flex";
        }

        function closeModal(postId) {
            document.getElementById("modal" + postId).style.display = "none";
        }

        function deletePost(postId) {
            if (confirm('Are you sure you want to delete this post?')) {
                alert("Post deleted!");
                window.location.href = "delete_post.php?id=" + postId;
            }
        }
    </script>
</head>
<body>

<h1>Manage Your Posts</h1>

<?php if (!empty($posts)): ?>
    <table>
        <thead>
            <tr>
                <th>Title</th>
                <th>Content</th>
                <th>Module</th>
                <th>Image</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($posts as $post): ?>
                <tr>
                    <td><?= htmlspecialchars($post['title']) ?></td>
                    <td><?= htmlspecialchars(substr($post['content'], 0, 50)) ?>...</td>
                    <td><?= htmlspecialchars($post['module_name']) ?></td>
                    <td>
                        <?php if ($post['image']): ?>
                            <img src="<?= htmlspecialchars($post['image']) ?>" alt="Post Image">
                        <?php else: ?>
                            No image
                        <?php endif; ?>
                    </td>
                    <td>
                        <span class="emoji" onclick="openModal(<?= $post['id'] ?>)">✏️</span> | 
                        <span class="emoji" onclick="deletePost(<?= $post['id'] ?>)">🗑️</span>
                    </td>
                </tr>

                <!-- Modal Edit Post -->
                <div class="modal" id="modal<?= $post['id'] ?>">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h2>Edit Post</h2>
                            <span class="close" onclick="closeModal(<?= $post['id'] ?>)">&times;</span>
                        </div>
                        <div class="modal-body">
                            <form action="update_post.php" method="POST" enctype="multipart/form-data">
                                <input type="hidden" name="id" value="<?= $post['id'] ?>">
                                <label for="title">Title</label>
                                <input type="text" name="title" id="title" value="<?= htmlspecialchars($post['title']) ?>" required>

                                <label for="content">Content</label>
                                <textarea name="content" id="content" rows="5" required><?= htmlspecialchars($post['content']) ?></textarea>

                                <label for="module_id">Select Module</label>
                                <select name="module_id" id="module_id" required>
                                    <?php foreach ($modules as $module): ?>
                                        <option value="<?= $module['id'] ?>" <?= $module['id'] == $post['module_id'] ? 'selected' : '' ?>>
                                            <?= htmlspecialchars($module['name']) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>

                                <label for="image">Upload New Image (optional)</label>
                                <select name="image" id="image">
                                    <option value="">Select an Image</option>
                                    <?php foreach ($images as $image): ?>
                                        <option value="<?= $image['image'] ?>"><?= $image['image'] ?></option>
                                    <?php endforeach; ?>
                                </select>

                                <button type="submit">Update Post</button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php else: ?>
    <p>You have no posts.</p>
<?php endif; ?>

</body>
</html>

<?php include '../includes/footer.php'; ?>
