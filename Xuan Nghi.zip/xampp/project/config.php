<?php
// Config.php: File cấu hình chính cho dự án

// **Cấu hình cơ sở dữ liệu**
define('DB_HOST', 'localhost');           // Tên host
define('DB_NAME', 'student_forum');      // Tên cơ sở dữ liệu
define('DB_USER', 'root');               // Tên người dùng MySQL
define('DB_PASS', '');                   // Mật khẩu MySQL

// **URL gốc của dự án**
define('BASE_URL', '/project');          // URL gốc (thay đổi theo thư mục chứa dự án)

try {
    // Kết nối cơ sở dữ liệu
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8",
        DB_USER,
        DB_PASS
    );
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    // Log lỗi và dừng chương trình nếu kết nối thất bại
    error_log("Lỗi kết nối cơ sở dữ liệu: " . $e->getMessage(), 0);
    die("Có lỗi xảy ra khi kết nối cơ sở dữ liệu.");
}
?>
