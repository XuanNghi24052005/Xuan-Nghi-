<?php
// Khởi tạo session nếu chưa có
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Hàm kiểm tra nếu người dùng đăng nhập và có vai trò hợp lệ
function check_login($role = 'user') {
    if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== $role) {
        header('Location: /project/user/login.php');
        exit;
    }
}

// Hàm logout để hủy session và chuyển hướng người dùng về trang đăng nhập
function logout() {
    // Kiểm tra nếu session đã được khởi động
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }

    // Xóa tất cả các session
    session_unset();

    // Hủy session
    session_destroy();

    // Chuyển hướng về trang đăng nhập
    header('Location: /project/user/login.php'); // Chỉnh đường dẫn nếu cần
    exit();
}

// Hàm hiển thị tên người dùng và vai trò (được gọi trong profile hoặc header)
function display_user_info() {
    if (isset($_SESSION['user'])) {
        echo 'Xin chào, ' . escape($_SESSION['user']['username']) . ' (' . escape($_SESSION['user']['role']) . ')';
    } else {
        echo 'Chưa đăng nhập';
    }
}

// Hàm thoát HTML để tránh XSS
function escape($str) {
    return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
}

// Hàm cập nhật thông tin người dùng
function update_profile($user_id, $new_username, $new_email, $new_password = null) {
    global $pdo;

    try {
        if ($new_password) {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, password = ? WHERE id = ?");
            $stmt->execute([$new_username, $new_email, $hashed_password, $user_id]);
        } else {
            $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ? WHERE id = ?");
            $stmt->execute([$new_username, $new_email, $user_id]);
        }
    } catch (PDOException $e) {
        die("Error updating profile: " . $e->getMessage());
    }
}

// Hàm hiển thị thông báo thành công hoặc lỗi
function show_message($message, $type = 'success') {
    $class = $type == 'success' ? 'alert-success' : 'alert-danger';
    echo "<div class='alert $class'>$message</div>";
}

// Hàm làm sạch dữ liệu đầu vào để tránh XSS hoặc SQL Injection
function sanitize_input($data) {
    $data = trim($data); // Loại bỏ khoảng trắng thừa
    $data = stripslashes($data); // Loại bỏ ký tự backslashes
    $data = htmlspecialchars($data); // Chuyển đổi các ký tự đặc biệt thành HTML entities
    return $data;
}

// Hàm kiểm tra và xác thực dữ liệu khi người dùng gửi form
function validate_user_input($data, $type = 'text') {
    if ($type == 'email') {
        if (!filter_var($data, FILTER_VALIDATE_EMAIL)) {
            return 'Email không hợp lệ';
        }
    } elseif ($type == 'password') {
        if (strlen($data) < 6) {
            return 'Mật khẩu phải có ít nhất 6 ký tự';
        }
    } elseif ($type == 'text') {
        if (empty($data)) {
            return 'Trường này không được để trống';
        }
    }
    return true; // Nếu dữ liệu hợp lệ
}

// Hàm kiểm tra sự tồn tại của email trong cơ sở dữ liệu
function check_email_exists($email) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    return $stmt->fetch(PDO::FETCH_ASSOC) ? true : false;
}

// Hàm xử lý đăng ký người dùng
function register_user($username, $email, $password) {
    global $pdo;

    // Kiểm tra email hợp lệ
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return "Email không hợp lệ";
    }

    if (check_email_exists($email)) {
        return "Email đã tồn tại";
    }

    try {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)");
        $stmt->execute([$username, $email, $hashed_password, 'user']);
        return true;
    } catch (PDOException $e) {
        die("Error registering user: " . $e->getMessage());
    }
}

// Hàm xử lý đăng nhập người dùng
function login_user($email, $password) {
    global $pdo;

    try {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user'] = [
                'id' => $user['id'],
                'username' => $user['username'],
                'email' => $user['email'],
                'role' => $user['role']
            ];
            return true;
        }
        return false;
    } catch (PDOException $e) {
        die("Error logging in: " . $e->getMessage());
    }
}
?>
