<?php
// Kiểm tra nếu session chưa bắt đầu thì mới gọi session_start()
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Kiểm tra người dùng đã đăng nhập chưa
$is_logged_in = isset($_SESSION['user']); // Kiểm tra nếu người dùng đã đăng nhập
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Forum</title>

    <!-- Import Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

    <style>
        /* Các style bổ sung */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
        }

        header {
            background-color: #A7DB42; /* Màu mới cho header */
            color: white;
            padding: 20px 0;
        }

        .navbar {
            background-color: #A7DB42; /* Màu mới cho navbar */
        }

        .navbar-nav .nav-item .nav-link {
            font-size: 1.1rem;
            padding-left: 15px;
            padding-right: 15px;
            color: #007bff; /* Màu xanh cho chữ */
        }

        .navbar-nav .nav-item .nav-link i {
            margin-right: 8px;
        }

        .navbar-nav .nav-item .nav-link:hover {
            color: #0056b3; /* Màu xanh đậm khi hover */
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 5px;
        }

        .modal-content {
            max-width: 500px;
            margin: 5% auto;
            padding: 20px;
        }

        .modal-header .close {
            color: #aaa;
            font-size: 28px;
        }

        .modal-header .close:hover {
            color: #000;
        }
    </style>
</head>
<body>

<header>
    <div class="container">
        <h1 class="text-center">Student Forum</h1>

        <nav class="navbar navbar-expand-lg navbar-dark">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="/project/user/index.php"><i class="fas fa-home"></i> Home</a>
                    </li>
                    <li class="nav-item">
                        <?php if ($is_logged_in): ?>
                            <a class="nav-link" href="/project/user/post.php"><i class="fas fa-pencil-alt"></i> Post </a>
                        <?php else: ?>
                            <a class="nav-link" href="javascript:void(0)" onclick="showModal()"><i class="fas fa-pencil-alt"></i> Post Question</a>
                        <?php endif; ?>
                    </li>
                    <li class="nav-item">
                        <?php if ($is_logged_in): ?>
                            <a class="nav-link" href="/project/user/contact.php"><i class="fas fa-envelope"></i> Contact</a>
                        <?php else: ?>
                            <a class="nav-link" href="javascript:void(0)" onclick="showModal()"><i class="fas fa-envelope"></i> Contact</a>
                        <?php endif; ?>
                    </li>
                    <li class="nav-item dropdown">
                        <?php if ($is_logged_in): ?>
                            <!-- Người dùng đã đăng nhập -->
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-user"></i> Welcome, <?= htmlspecialchars($_SESSION['user']['username']); ?> (<?= htmlspecialchars($_SESSION['user']['role']); ?>)
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="/project/user/profile.php">Update Profile</a></li>
                                <li><a class="dropdown-item" href="/project/user/logout.php">Logout</a></li>
                            </ul>
                        <?php else: ?>
                            <!-- Người dùng chưa đăng nhập -->
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-user"></i> Profile
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="/project/user/login.php">Login</a></li>
                                <li><a class="dropdown-item" href="/project/user/register.php">Register</a></li>
                            </ul>
                        <?php endif; ?>
                    </li>
                </ul>
            </div>
        </nav>
    </div>
</header>

<!-- Modal for non-logged-in users -->
<div id="loginModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="loginModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="loginModalLabel">Login or Register</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>You need to log in or register to use this feature.</p>
                <a href="/project/user/login.php" class="btn btn-primary btn-block">Login</a>
                <a href="/project/user/register.php" class="btn btn-secondary btn-block">Register</a>
            </div>
        </div>
    </div>
</div>

<!-- Import Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

<script>
    // Show Modal when user tries to access restricted pages
    function showModal() {
        var myModal = new bootstrap.Modal(document.getElementById('loginModal'));
        myModal.show();
    }
</script>

</body>
</html>
