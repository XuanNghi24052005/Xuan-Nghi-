<?php
// Footer.php
?>
</main>
<footer>
    <p style="text-align: center; background: #f4f4f4; padding: 10px;">&copy; Student Forum Create by xNghi 🦫 </p>
</footer>
</body>
</html>
