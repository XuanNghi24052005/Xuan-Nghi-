<?php
session_start();
require_once '../config.php'; // Kết nối cơ sở dữ liệu

// Kiểm tra nếu chưa đăng nhập và chưa có session admin_logged_in, chuyển hướng đến trang login
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header('Location: ../user/login.php');
    exit;
}

// Lấy thông tin admin từ session
$admin_id = $_SESSION['user']['id']; // ID admin từ session

// Truy vấn thông tin admin từ cơ sở dữ liệu
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ? AND role = 'admin'");
$stmt->execute([$admin_id]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);

// Nếu không tìm thấy admin, chuyển hướng về trang login
if (!$admin) {
    header('Location: ../user/login.php');
    exit;
}

// Lấy danh sách tin nhắn từ cơ sở dữ liệu
$stmt = $pdo->prepare("SELECT * FROM messages ORDER BY created_at DESC");
$stmt->execute();
$messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Contacts 📩</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            min-height: 100vh;
            margin: 0;
        }

        .sidebar {
            width: 250px;
            background-color: #343a40;
            color: white;
            height: 100vh;
            padding-top: 20px;
            position: fixed;
        }

        .sidebar a {
            color: white;
            padding: 15px;
            text-decoration: none;
            display: block;
            font-size: 18px;
        }

        .sidebar a:hover {
            background-color: #575757;
        }

        .sidebar .logout {
            position: absolute;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            background-color: #e74c3c;
            color: white;
            padding: 10px 20px;
            text-align: center;
            border-radius: 5px;
            cursor: pointer;
        }

        .main-content {
            margin-left: 250px;
            padding: 20px;
            flex-grow: 1;
        }

        .header {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            text-align: center;
        }

        .header h1 {
            margin: 0;
        }

        .table-container {
            margin: 20px auto;
            background: #ffffff;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }

        .popup {
            position: fixed;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            z-index: 1000;
            display: none;
        }
    </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <a href="dashboard.php">📊 Dashboard</a>
    <a href="manage_modules.php">📚 Manage Modules</a>
    <a href="manage_posts.php">📝 Manage Posts</a>
    <a href="manage_users.php">👥 Manage Users</a>
    <a href="manage_contact.php">📩 Manage Contacts</a>
    <a href="settings.php">⚙️ Settings</a>
    <div class="logout" onclick="window.location.href='settings.php?logout=true'">🚪 Logout</div>
</div>

<!-- Main Content -->
<div class="main-content">
    <div class="header">
        <h1>Manage Contact Messages 📩</h1>
    </div>

    <!-- Popup thông báo thành công -->
    <?php if (isset($_GET['success']) && $_GET['success'] == 'true'): ?>
        <div class="popup alert alert-success text-center" id="popupMessage" role="alert">
            The message has been deleted successfully! 🦫
        </div>
    <?php endif; ?>

    <div class="table-container">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Message</th>
                    <th scope="col">Date</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($messages as $message): ?>
                    <tr>
                        <td><?= htmlspecialchars($message['id']) ?></td>
                        <td><?= htmlspecialchars($message['name']) ?></td>
                        <td><?= htmlspecialchars($message['email']) ?></td>
                        <td><?= nl2br(htmlspecialchars($message['message'])) ?></td>
                        <td><?= htmlspecialchars($message['created_at']) ?></td>
                        <td>
                            <!-- Button trigger modal -->
                            <button class="btn btn-info btn-sm" data-bs-toggle="modal" data-bs-target="#viewMessageModal<?= $message['id'] ?>">View</button>
                            <a href="delete_message.php?id=<?= $message['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this message?')">Delete</a>
                        </td>
                    </tr>

                    <!-- Modal View Message -->
                    <div class="modal fade" id="viewMessageModal<?= $message['id'] ?>" tabindex="-1" aria-labelledby="viewMessageModalLabel<?= $message['id'] ?>" aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="viewMessageModalLabel<?= $message['id'] ?>">Message Details</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <p><strong>Name:</strong> <?= htmlspecialchars($message['name']) ?></p>
                                    <p><strong>Email:</strong> <?= htmlspecialchars($message['email']) ?></p>
                                    <p><strong>Message:</strong><br><?= nl2br(htmlspecialchars($message['message'])) ?></p>
                                    <p><strong>Date:</strong> <?= htmlspecialchars($message['created_at']) ?></p>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </div>
                    </div>

                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

</div>

<!-- Bootstrap Bundle JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Hiển thị popup và ẩn nó sau 2 giây
    <?php if (isset($_GET['success']) && $_GET['success'] == 'true'): ?>
        document.getElementById('popupMessage').style.display = 'block';
        setTimeout(function () {
            document.getElementById('popupMessage').style.display = 'none';
        }, 2000);
    <?php endif; ?>
</script>
</body>
</html>
