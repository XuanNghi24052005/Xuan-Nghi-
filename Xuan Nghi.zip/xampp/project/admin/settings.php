<?php
session_start();
require_once '../config.php'; // Kết nối cơ sở dữ liệu

// Kiểm tra nếu chưa đăng nhập và chưa có session admin_logged_in, chuyển hướng đến trang login
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header('Location: ../user/login.php');
    exit;
}

// Lấy thông tin admin từ session
$admin_id = $_SESSION['user']['id']; // ID admin từ session

// Truy vấn thông tin admin từ cơ sở dữ liệu
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ? AND role = 'admin'");
$stmt->execute([$admin_id]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);

// Nếu không tìm thấy admin, chuyển hướng về trang login
if (!$admin) {
    header('Location: ../user/login.php');
    exit;
}

// Xử lý cập nhật thông tin cá nhân
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_profile'])) {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];

    // Kiểm tra mật khẩu hiện tại
    if (password_verify($current_password, $admin['password'])) {
        // Cập nhật thông tin người dùng
        $update_stmt = $pdo->prepare("UPDATE users SET username = ?, email = ? WHERE id = ?");
        $update_stmt->execute([$username, $email, $admin_id]);

        // Cập nhật mật khẩu nếu có thay đổi
        if (!empty($new_password)) {
            $hashed_new_password = password_hash($new_password, PASSWORD_BCRYPT);
            $update_stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
            $update_stmt->execute([$hashed_new_password, $admin_id]);
        }

        // Thông báo cập nhật thành công
        $message = "Profile updated successfully! ✅";
    } else {
        $message = "Current password is incorrect! ❌";
    }
}

// Xử lý logout
if (isset($_GET['logout'])) {
    session_unset();
    session_destroy();
    header('Location: ../user/login.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Settings ⚙️</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            min-height: 100vh;
            margin: 0;
        }

        .sidebar {
            width: 250px;
            background-color: #343a40;
            color: white;
            height: 100vh;
            padding-top: 20px;
            position: fixed;
        }

        .sidebar a {
            color: white;
            padding: 15px;
            text-decoration: none;
            display: block;
            font-size: 18px;
        }

        .sidebar a:hover {
            background-color: #575757;
        }

        .sidebar .logout {
            position: absolute;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            background-color: #e74c3c;
            color: white;
            padding: 10px 20px;
            text-align: center;
            border-radius: 5px;
            cursor: pointer;
        }

        .main-content {
            margin-left: 250px;
            padding: 20px;
            flex-grow: 1;
        }

        .header {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            text-align: center;
        }

        .header h1 {
            margin: 0;
        }

        form { width: 100%; max-width: 500px; margin: 0 auto; }
        input[type="text"], input[type="email"], input[type="password"], button {
            width: 100%; padding: 10px; margin: 10px 0; border: 1px solid #ddd; border-radius: 5px;
        }
        button { background-color: #007bff; color: white; border: none; cursor: pointer; }
        button:hover { background-color: #0056b3; }

        .message { color: green; margin-top: 10px; }
        .error { color: red; margin-top: 10px; }
    </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <a href="dashboard.php">📊 Dashboard</a>
    <a href="manage_modules.php">📚 Manage Modules</a>
    <a href="manage_posts.php">📝 Manage Posts</a>
    <a href="manage_users.php">👥 Manage Users</a>
    <a href="settings.php">⚙️ Settings</a>
    <div class="logout" onclick="window.location.href='settings.php?logout=true'">🚪 Logout</div>
</div>

<!-- Main Content -->
<div class="main-content">
    <div class="header">
        <h1>Settings ⚙️</h1>
    </div>

    <h2>Update Profile ✍️</h2>

    <!-- Hiển thị thông báo nếu có -->
    <?php if (isset($message)) { ?>
        <div class="message"><?= $message ?></div>
    <?php } elseif (isset($error)) { ?>
        <div class="error"><?= $error ?></div>
    <?php } ?>

    <!-- Form Cập nhật thông tin cá nhân -->
    <form method="POST">
        <input type="hidden" name="update_profile" value="1">
        
        <label for="username">Username 🧑‍💻</label>
        <input type="text" id="username" name="username" value="<?= htmlspecialchars($admin['username']) ?>" required>

        <label for="email">Email 📧</label>
        <input type="email" id="email" name="email" value="<?= htmlspecialchars($admin['email']) ?>" required>

        <label for="current_password">Current Password 🔑</label>
        <input type="password" id="current_password" name="current_password" required>

        <label for="new_password">New Password 🔐 (leave blank to keep current password)</label>
        <input type="password" id="new_password" name="new_password">

        <button type="submit">Update Profile 🔄</button>
    </form>
</div>

<!-- Bootstrap 5 JS -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>

</body>
</html>
