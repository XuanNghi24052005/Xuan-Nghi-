<?php
// Bắt đầu session
session_start();

// Hủy tất cả session
session_unset();

// Hủy session
session_destroy();

// Chuyển hướng người dùng về trang đăng nhập
header('Location: ../user/login.php');
exit;
