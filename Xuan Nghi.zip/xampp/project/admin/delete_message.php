<?php
session_start();
require_once '../config.php'; // Kết nối cơ sở dữ liệu

// Kiểm tra nếu chưa đăng nhập và chưa có session admin_logged_in, chuyển hướng đến trang login
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header('Location: ../user/login.php');
    exit;
}

// Lấy thông tin admin từ session
$admin_id = $_SESSION['user']['id']; // ID admin từ session

// Truy vấn thông tin admin từ cơ sở dữ liệu
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ? AND role = 'admin'");
$stmt->execute([$admin_id]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);

// Nếu không tìm thấy admin, chuyển hướng về trang login
if (!$admin) {
    header('Location: ../user/login.php');
    exit;
}

// Kiểm tra và lấy ID của tin nhắn
if (isset($_GET['id'])) {
    $message_id = $_GET['id'];

    // Lấy tin nhắn từ cơ sở dữ liệu để kiểm tra tồn tại
    $stmt = $pdo->prepare("SELECT * FROM messages WHERE id = ?");
    $stmt->execute([$message_id]);
    $message = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($message) {
        // Xóa tin nhắn
        $delete_stmt = $pdo->prepare("DELETE FROM messages WHERE id = ?");
        $delete_stmt->execute([$message_id]);

        // Chuyển hướng về trang quản lý tin nhắn với thông báo thành công
        header('Location: manage_contact.php?success=true');
        exit;
    } else {
        // Nếu không tìm thấy tin nhắn, chuyển về trang quản lý
        header('Location: manage_contact.php');
        exit;
    }
} else {
    header('Location: manage_contact.php');
    exit;
}
?>
