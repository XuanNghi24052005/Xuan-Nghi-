<?php
require_once '../config.php';
session_start();

// Kiểm tra quyền truy cập (chỉ admin mới được vào)
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header('Location: ../user/login.php');
    exit;
}

$user = $_SESSION['user'];

// Lấy tổng số người dùng, bài viết, tin nhắn và modules
$stmt = $pdo->prepare("SELECT COUNT(*) AS total_users FROM users WHERE role != 'admin'");
$stmt->execute();
$total_users = $stmt->fetch(PDO::FETCH_ASSOC)['total_users'];

$stmt = $pdo->prepare("SELECT COUNT(*) AS total_posts FROM posts");
$stmt->execute();
$total_posts = $stmt->fetch(PDO::FETCH_ASSOC)['total_posts'];

$stmt = $pdo->prepare("SELECT COUNT(*) AS total_messages FROM messages");
$stmt->execute();
$total_messages = $stmt->fetch(PDO::FETCH_ASSOC)['total_messages'];

$stmt = $pdo->prepare("SELECT COUNT(*) AS total_modules FROM modules");
$stmt->execute();
$total_modules = $stmt->fetch(PDO::FETCH_ASSOC)['total_modules'];

// Lấy số lượng người dùng theo vai trò
$stmt = $pdo->prepare("SELECT role, COUNT(*) AS count FROM users GROUP BY role");
$stmt->execute();
$user_roles = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="styles.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            min-height: 100vh;
            margin: 0;
        }

        .sidebar {
            width: 250px;
            background-color: #333;
            color: white;
            height: 100vh;
            padding-top: 20px;
            position: fixed;
        }

        .sidebar a {
            color: white;
            padding: 15px;
            text-decoration: none;
            display: block;
            font-size: 18px;
        }

        .sidebar a:hover {
            background-color: #575757;
        }

        .main-content {
            margin-left: 250px;
            padding: 20px;
            flex-grow: 1;
        }

        .header {
            background-color: #007BFF;
            color: white;
            padding: 10px 20px;
            text-align: center;
        }

        .header h1 {
            margin: 0;
        }

        .sidebar .logout {
            position: absolute;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            background-color: #e74c3c;
            color: white;
            padding: 10px 20px;
            text-align: center;
            border-radius: 5px;
            cursor: pointer;
        }

        .content {
            margin-top: 20px;
        }

        .overview-table {
            margin-top: 20px;
            background: #ffffff;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }

        .chart-container {
            margin-top: 20px;
        }

        .chart-box {
            background: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .filters {
            margin: 20px 0;
        }

        .filters label {
            margin-right: 10px;
        }

        .filters input {
            margin-right: 20px;
        }

    </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <a href="dashboard.php">📊 Dashboard</a>
    <a href="manage_modules.php">📚 Manage Modules</a>
    <a href="manage_posts.php">📝 Manage Posts</a>
    <a href="manage_users.php">👥 Manage Users</a>
    <a href="manage_contact.php">📩 Manage Contacts</a>
    <a href="settings.php">⚙️ Settings</a>
    <div class="logout" onclick="window.location.href='settings.php?logout=true'">🚪 Logout</div>
</div>

<!-- Main Content -->
<div class="main-content">
    <div class="header">
        <h1>Admin Dashboard</h1>
    </div>
    
    <div class="content">
        <h2>Welcome, <?php echo htmlspecialchars($user['username']); ?>!</h2>
        <p>You are logged in as an admin. From here, you can manage all the modules, users, posts, and settings.</p>
        
        <!-- Overview Table -->
        <div class="overview-table">
            <h4>Overview</h4>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">Metric</th>
                        <th scope="col">Count</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Total Users</td>
                        <td><?php echo $total_users; ?></td>
                    </tr>
                    <tr>
                        <td>Total Posts</td>
                        <td><?php echo $total_posts; ?></td>
                    </tr>
                    <tr>
                        <td>Total Messages</td>
                        <td><?php echo $total_messages; ?></td>
                    </tr>
                    <tr>
                        <td>Total Modules</td>
                        <td><?php echo $total_modules; ?></td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- Filters -->
        <div class="filters">
            <label for="dateRange">Date Range: </label>
            <input type="date" id="startDate" name="startDate">
            <input type="date" id="endDate" name="endDate">

            <label><input type="checkbox" id="showUsers" checked> Show User Roles</label>
            <label><input type="checkbox" id="showPosts" checked> Show Posts</label>
            <label><input type="checkbox" id="showMessages" checked> Show Messages</label>
            <label><input type="checkbox" id="showModules" checked> Show Modules</label>
        </div>

        <!-- Combined Chart (Bar Chart) -->
        <div class="chart-container">
            <div class="chart-box">
                <h4>Dashboard Statistics</h4>
                <canvas id="combinedChart"></canvas>
            </div>
        </div>

    </div>
</div>

<script>
// Lấy giá trị từ checkbox và cập nhật biểu đồ
document.addEventListener('DOMContentLoaded', function () {
    var ctxCombined = document.getElementById('combinedChart').getContext('2d');
    
    // Tạo dữ liệu mặc định cho biểu đồ
    var chartData = {
        labels: <?php echo json_encode(array_column($user_roles, 'role')); ?>,
        datasets: []
    };
    
    // Thêm các dataset dựa trên checkbox đã chọn
    function updateChartData() {
        var datasets = [];
        
        if (document.getElementById('showUsers').checked) {
            datasets.push({
                label: 'User Roles Count',
                data: <?php echo json_encode(array_column($user_roles, 'count')); ?>,
                backgroundColor: '#4e73df',
                borderColor: '#4e73df',
                borderWidth: 1
            });
        }
        
        if (document.getElementById('showPosts').checked) {
            datasets.push({
                label: 'Posts Count',
                data: [<?php echo $total_posts; ?>, <?php echo $total_posts; ?>, <?php echo $total_posts; ?>],
                backgroundColor: '#1cc88a',
                borderColor: '#1cc88a',
                borderWidth: 1
            });
        }
        
        if (document.getElementById('showMessages').checked) {
            datasets.push({
                label: 'Messages Count',
                data: [<?php echo $total_messages; ?>, <?php echo $total_messages; ?>, <?php echo $total_messages; ?>],
                backgroundColor: '#f6c23e',
                borderColor: '#f6c23e',
                borderWidth: 1
            });
        }
        
        if (document.getElementById('showModules').checked) {
            datasets.push({
                label: 'Modules Count',
                data: [<?php echo $total_modules; ?>, <?php echo $total_modules; ?>, <?php echo $total_modules; ?>],
                backgroundColor: '#e74a3b',
                borderColor: '#e74a3b',
                borderWidth: 1
            });
        }
        
        chartData.datasets = datasets;
        
        // Cập nhật biểu đồ
        chart.update();
    }

    var chart = new Chart(ctxCombined, {
        type: 'bar', // Biểu đồ cột
        data: chartData,
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        beginAtZero: true
                    }
                }
            },
            plugins: {
                legend: {
                    position: 'top'
                }
            }
        }
    });

    // Lắng nghe thay đổi checkbox để cập nhật biểu đồ
    document.querySelectorAll('.filters input[type="checkbox"]').forEach(function (checkbox) {
        checkbox.addEventListener('change', updateChartData);
    });

    // Cập nhật dữ liệu biểu đồ khi trang được tải lần đầu
    updateChartData();
});
</script>

</body>
</html>
