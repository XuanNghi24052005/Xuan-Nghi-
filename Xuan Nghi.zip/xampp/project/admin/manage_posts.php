<?php
session_start();
require_once '../config.php'; // Kết nối cơ sở dữ liệu

// Kiểm tra nếu chưa đăng nhập và chưa có session admin_logged_in, chuyển hướng đến trang login
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header('Location: ../user/login.php');
    exit;
}

// Lấy thông tin admin từ session
$admin_id = $_SESSION['user']['id']; // ID admin từ session

// Truy vấn thông tin admin từ cơ sở dữ liệu
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ? AND role = 'admin'");
$stmt->execute([$admin_id]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);

// Nếu không tìm thấy admin, chuyển hướng về trang login
if (!$admin) {
    header('Location: ../user/login.php');
    exit;
}
// Xử lý xóa bài viết
if (isset($_GET['delete_id'])) {
    $post_id = $_GET['delete_id'];

    // Bắt đầu giao dịch (transaction) để đảm bảo xóa đồng bộ
    $pdo->beginTransaction();
    
    try {
        // Xóa tất cả các like liên quan đến bài viết
        $stmt = $pdo->prepare("DELETE FROM likes WHERE post_id = ?");
        $stmt->execute([$post_id]);

        // Xóa tất cả các bình luận liên quan đến bài viết
        $stmt = $pdo->prepare("DELETE FROM comments WHERE post_id = ?");
        $stmt->execute([$post_id]);

        // Xóa bài viết
        $stmt = $pdo->prepare("DELETE FROM posts WHERE id = ?");
        $stmt->execute([$post_id]);

        // Cam kết giao dịch (commit)
        $pdo->commit();

        // Quay lại trang quản lý bài viết
        header('Location: manage_posts.php');
        exit;

    } catch (Exception $e) {
        // Nếu có lỗi, rollback giao dịch
        $pdo->rollBack();
        echo 'Error: ' . $e->getMessage();
    }
}

// Lấy danh sách bài viết
$query = $pdo->query("SELECT posts.id, posts.title, users.username, modules.name AS module_name, posts.created_at 
                      FROM posts
                      LEFT JOIN users ON posts.user_id = users.id
                      LEFT JOIN modules ON posts.module_id = modules.id");
$posts = $query->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Posts</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            min-height: 100vh;
            margin: 0;
            background-color: #f8f9fa;
        }

        .sidebar {
            width: 250px;
            background-color: #343a40;
            color: white;
            height: 100vh;
            padding-top: 20px;
            position: fixed;
        }

        .sidebar a {
            color: white;
            padding: 15px;
            text-decoration: none;
            display: block;
            font-size: 18px;
        }

        .sidebar a:hover {
            background-color: #495057;
        }

        .sidebar .logout {
            position: absolute;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            background-color: #e74c3c;
            color: white;
            padding: 10px 20px;
            text-align: center;
            border-radius: 5px;
            cursor: pointer;
        }

        .main-content {
            margin-left: 250px;
            padding: 20px;
            flex-grow: 1;
        }

        .header {
            background-color: #007BFF;
            color: white;
            padding: 10px 20px;
            text-align: center;
            border-radius: 5px;
        }

        .header h1 {
            margin: 0;
        }

        .table {
            margin-top: 20px;
        }

        .btn {
            margin-right: 5px;
        }
    </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <a href="dashboard.php">📊 Dashboard</a>
    <a href="manage_modules.php">📚 Manage Modules</a>
    <a href="manage_posts.php">📝 Manage Posts</a>
    <a href="manage_users.php">👥 Manage Users</a>
    <a href="manage_contact.php">📩 Manage Contacts</a>
    <a href="settings.php">⚙️ Settings</a>
    <div class="logout" onclick="window.location.href='settings.php?logout=true'">🚪 Logout</div>
</div>

<!-- Main Content -->
<div class="main-content">
    <div class="header">
        <h1>Admin Dashboard - Manage Posts</h1>
    </div>

    <h2>🔗 Post Management</h2>

    <!-- Posts Table -->
    <table class="table table-striped">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Title</th>
                <th>Author</th>
                <th>Module</th>
                <th>Created At</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($posts as $post): ?>
                <tr>
                    <td><?= $post['id'] ?></td>
                    <td><?= htmlspecialchars($post['title']) ?></td>
                    <td><?= htmlspecialchars($post['username']) ?></td>
                    <td><?= htmlspecialchars($post['module_name']) ?></td>
                    <td><?= $post['created_at'] ?></td>
                    <td>
                        <a href="?delete_id=<?= $post['id'] ?>" 
                           class="btn btn-danger btn-sm"
                           onclick="return confirm('Are you sure you want to delete this post?')">
                            🗑️ Delete
                        </a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

</body>
</html>

