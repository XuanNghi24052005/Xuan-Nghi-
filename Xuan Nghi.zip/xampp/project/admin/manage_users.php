<?php
session_start();
require_once '../config.php'; // Kết nối cơ sở dữ liệu

// Kiểm tra nếu chưa đăng nhập và chưa có session admin_logged_in, chuyển hướng đến trang login
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header('Location: ../user/login.php');
    exit;
}

// Lấy thông tin admin từ session
$admin_id = $_SESSION['user']['id']; // ID admin từ session

// Truy vấn thông tin admin từ cơ sở dữ liệu
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ? AND role = 'admin'");
$stmt->execute([$admin_id]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);

// Nếu không tìm thấy admin, chuyển hướng về trang login
if (!$admin) {
    header('Location: ../user/login.php');
    exit;
}

// Thêm người dùng (Add User)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'add_user') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT); // Mã hóa mật khẩu
    $role = $_POST['role'];

    $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)");
    $stmt->execute([$username, $email, $password, $role]);

    // Sau khi thêm thành công, chuyển hướng lại trang manage_users.php
    header('Location: manage_users.php');
    exit;
}

// Chỉnh sửa người dùng (Edit User)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'edit_user') {
    $user_id = $_POST['user_id'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $role = $_POST['role'];

    $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, role = ? WHERE id = ?");
    $stmt->execute([$username, $email, $role, $user_id]);

    // Sau khi cập nhật thành công, chuyển hướng lại trang manage_users.php
    header('Location: manage_users.php');
    exit;
}

// Xóa người dùng (Delete User)
if (isset($_GET['delete_id'])) {
    $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
    $stmt->execute([$_GET['delete_id']]);

    // Sau khi xóa thành công, chuyển hướng lại trang manage_users.php
    header('Location: manage_users.php');
    exit;
}

// Lấy danh sách người dùng
$query = $pdo->query("SELECT * FROM users");
$users = $query->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            display: flex;
            min-height: 100vh;
            margin: 0;
        }
        
        .sidebar {
            width: 250px;
            background-color: #343a40;
            color: white;
            height: 100vh;
            padding-top: 20px;
            position: fixed;
        }

        .sidebar a {
            color: white;
            padding: 15px;
            text-decoration: none;
            display: block;
            font-size: 18px;
        }

        .sidebar a:hover {
            background-color: #495057;
        }

        .sidebar .logout {
            position: absolute;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            background-color: #e74c3c;
            color: white;
            padding: 10px 20px;
            text-align: center;
            border-radius: 5px;
            cursor: pointer;
        }

        .main-content {
            margin-left: 250px;
            padding: 20px;
            flex-grow: 1;
        }

        .header {
            background-color: #007BFF;
            color: white;
            padding: 10px 20px;
            text-align: center;
        }

        .header h1 {
            margin: 0;
        }

        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
        th { background: #f4f4f4; }
        button { background-color: #007BFF; color: white; padding: 10px 15px; border: none; cursor: pointer; }
        button:hover { background-color: #0056b3; }
        .modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0, 0, 0, 0.5); padding-top: 60px; }
        .modal-content { background-color: white; padding: 20px; margin: 5% auto; width: 80%; }
        .close { color: #aaa; float: right; font-size: 28px; font-weight: bold; }
        .close:hover, .close:focus { color: black; text-decoration: none; cursor: pointer; }
    </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <a href="dashboard.php">📊 Dashboard</a>
    <a href="manage_modules.php">📚 Manage Modules</a>
    <a href="manage_posts.php">📝 Manage Posts</a>
    <a href="manage_users.php">👥 Manage Users</a>
    <a href="manage_contact.php">📩 Manage Contacts</a>
    <a href="settings.php">⚙️ Settings</a>
    <div class="logout" onclick="window.location.href='settings.php?logout=true'">🚪 Logout</div>
</div>


<!-- Main Content -->
<div class="main-content">
    <div class="header">
        <h1>Admin Dashboard - Manage Users 👥</h1>
    </div>

    <h2>Manage Users</h2>

    <button id="addUserBtn" class="btn btn-primary mb-3">➕ Add New User</button>

    <!-- Bảng người dùng -->
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Email</th>
                <th>Role</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $user): ?>
            <tr>
                <td><?= $user['id'] ?></td>
                <td><?= htmlspecialchars($user['username']) ?></td>
                <td><?= htmlspecialchars($user['email']) ?></td>
                <td><?= htmlspecialchars($user['role']) ?></td>
                <td>
                    <button class="btn btn-warning editBtn" data-id="<?= $user['id'] ?>" data-username="<?= htmlspecialchars($user['username']) ?>" data-email="<?= htmlspecialchars($user['email']) ?>" data-role="<?= $user['role'] ?>">✏️ Edit</button> 
                    <button class="btn btn-danger deleteBtn" data-id="<?= $user['id'] ?>">❌ Delete</button>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- Modal Add User -->
<div id="addUserModal" class="modal">
    <div class="modal-content">
        <span class="close" id="closeAddModal">&times;</span>
        <h2>Add New User</h2>
        <form id="addUserForm" method="POST">
            <input type="hidden" name="action" value="add_user">
            <div class="mb-3">
                <label for="username" class="form-label">Username:</label>
                <input type="text" class="form-control" id="username" name="username" required>
            </div>

            <div class="mb-3">
                <label for="email" class="form-label">Email:</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>

            <div class="mb-3">
                <label for="password" class="form-label">Password:</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>

            <div class="mb-3">
                <label for="role" class="form-label">Role:</label>
                <select class="form-select" id="role" name="role">
                    <option value="Admin">Admin</option>
                    <option value="User">User</option>
                </select>
            </div>

            <button type="submit" class="btn btn-success">Add User</button>
        </form>
    </div>
</div>

<!-- Modal Edit User -->
<div id="editUserModal" class="modal">
    <div class="modal-content">
        <span class="close" id="closeEditModal">&times;</span>
        <h2>Edit User</h2>
        <form id="editUserForm" method="POST">
            <input type="hidden" name="action" value="edit_user">
            <input type="hidden" id="user_id" name="user_id">
            <div class="mb-3">
                <label for="edit_username" class="form-label">Username:</label>
                <input type="text" class="form-control" id="edit_username" name="username" required>
            </div>

            <div class="mb-3">
                <label for="edit_email" class="form-label">Email:</label>
                <input type="email" class="form-control" id="edit_email" name="email" required>
            </div>

            <div class="mb-3">
                <label for="edit_role" class="form-label">Role:</label>
                <select class="form-select" id="edit_role" name="role">
                    <option value="Admin">Admin</option>
                    <option value="User">User</option>
                </select>
            </div>

            <button type="submit" class="btn btn-warning">Save Changes</button>
        </form>
    </div>
</div>

<!-- Modal Delete User -->
<div id="deleteUserModal" class="modal">
    <div class="modal-content">
        <span class="close" id="closeDeleteModal">&times;</span>
        <h2>Are you sure you want to delete this user?</h2>
        <button id="confirmDeleteBtn" class="btn btn-danger">Yes</button>
        <button id="cancelDeleteBtn" class="btn btn-secondary">No</button>
    </div>
</div>

<script>
    // JavaScript để quản lý modal
    const addUserBtn = document.getElementById("addUserBtn");
    const addUserModal = document.getElementById("addUserModal");
    const closeAddModal = document.getElementById("closeAddModal");

    const editUserModal = document.getElementById("editUserModal");
    const closeEditModal = document.getElementById("closeEditModal");

    const deleteUserModal = document.getElementById("deleteUserModal");
    const cancelDeleteBtn = document.getElementById("cancelDeleteBtn");
    const confirmDeleteBtn = document.getElementById("confirmDeleteBtn");

    let deleteUserId = null;

    addUserBtn.onclick = function() {
        addUserModal.style.display = "block";
    };

    closeAddModal.onclick = function() {
        addUserModal.style.display = "none";
    };

    // Khi bấm vào nút Edit
    const editBtns = document.querySelectorAll(".editBtn");
    editBtns.forEach(btn => {
        btn.onclick = function() {
            const userId = btn.getAttribute("data-id");
            const username = btn.getAttribute("data-username");
            const email = btn.getAttribute("data-email");
            const role = btn.getAttribute("data-role");

            document.getElementById("user_id").value = userId;
            document.getElementById("edit_username").value = username;
            document.getElementById("edit_email").value = email;
            document.getElementById("edit_role").value = role;

            editUserModal.style.display = "block";
        };
    });

    closeEditModal.onclick = function() {
        editUserModal.style.display = "none";
    };

    // Xóa người dùng
    const deleteBtns = document.querySelectorAll(".deleteBtn");
    deleteBtns.forEach(btn => {
        btn.onclick = function() {
            deleteUserId = btn.getAttribute("data-id");
            deleteUserModal.style.display = "block";
        };
    });

    cancelDeleteBtn.onclick = function() {
        deleteUserModal.style.display = "none";
    };

    confirmDeleteBtn.onclick = function() {
        if (deleteUserId) {
            window.location.href = "manage_users.php?delete_id=" + deleteUserId;
        }
    };

    // Đóng modal khi click ra ngoài
    window.onclick = function(event) {
        if (event.target == addUserModal || event.target == editUserModal || event.target == deleteUserModal) {
            addUserModal.style.display = "none";
            editUserModal.style.display = "none";
            deleteUserModal.style.display = "none";
        }
    }
</script>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>
</html>
